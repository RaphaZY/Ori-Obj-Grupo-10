class Curso:
    def __init__(self, nome, tipo_ensino, coordenador=None):
        self.nome = nome
        self.tipo_ensino = tipo_ensino
        self.coordenador = coordenador
