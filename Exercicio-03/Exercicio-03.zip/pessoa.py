class Pessoa:
    def __init__(self, nome, naturalidade, escolaridade):
        self.nome = nome
        self.naturalidade = naturalidade
        self.escolaridade = escolaridade
