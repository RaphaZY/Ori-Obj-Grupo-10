class TipoEnsino:
    def __init__(self, descricao):
        self.descricao = descricao
