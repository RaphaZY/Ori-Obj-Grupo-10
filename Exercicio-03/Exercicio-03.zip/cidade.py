class Cidade:
    def __init__(self, nome, estado):
        self.nome = nome
        self.estado = estado
