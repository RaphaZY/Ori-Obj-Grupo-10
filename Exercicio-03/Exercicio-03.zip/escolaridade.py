class Escolaridade:
    def __init__(self, descricao):
        self.descricao = descricao
