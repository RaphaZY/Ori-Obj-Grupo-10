class Escola:
    def __init__(self, nome, cidade, diretor=None):
        self.nome = nome
        self.cidade = cidade
        self.diretor = diretor
